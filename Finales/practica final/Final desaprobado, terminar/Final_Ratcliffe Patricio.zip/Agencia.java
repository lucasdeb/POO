import java.util.ArrayList;

public class Agencia {
    private ArrayList<Vehiculo> vehiculos;
    private ArrayList<Persona> clientes;

    public Agencia(){
        this.vehiculos= new ArrayList<Vehiculo>();
        this.clientes= new ArrayList<Persona>();
    }

    public Agencia(ArrayList<Vehiculo> vehiculos){
        for (Vehiculo vehiculo : vehiculos) {
            this.vehiculos.add(vehiculo);
        }
    }// Inicializada la agencia con el stock

    public ArrayList<Persona> getClientes() {
        return clientes;
    }
    public ArrayList<Vehiculo> getVehiculos() {
        return vehiculos;
    }

    public void registrarClientes(ArrayList<Persona> personas){
        switch (personas.size()) {
            case 2:
                
                break;
            case 4:
                
                break;
        
            default:

                break;
        }
    }

    public void recibirVehiculo(int dias){
        
    }

    public void mostrarRegistro(){
        for (Vehiculo vehiculo : this.vehiculos) {
            if (condition) {
                System.out.println("Vehiculos en stock:");
            }
        }
    }


}
