package Final;

public class Persona {
    String nombre;
    String apellido;
    int edad;
    String genero;
    int dni;

    public Persona(String nombre, String apellido, int edad, String genero, int dni){
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.genero = genero;
        this.dni = dni;
    }
}
