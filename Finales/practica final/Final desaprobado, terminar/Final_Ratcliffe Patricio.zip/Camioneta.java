public class Camioneta extends Vehiculo {
    
    public Camioneta(){}
    public Camioneta(String codigo, double costoAlquiler){
        super(codigo, costoAlquiler, 5);
    }
}
