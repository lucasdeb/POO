import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static Persona cargarPersona(){
        Scanner inputs= new Scanner(System.in);
        boolean bandera;

        System.out.println("Ingrese nombre:");
        String nombre= inputs.nextLine();
        System.out.println("Ingrese apellido:");
        String apellido= inputs.nextLine();
        System.out.println("Ingrese genero (Masculino/Femenino):");
        String genero= inputs.nextLine();
        System.out.println("Ingrese DNI:");
        int DNI=0;
        bandera= true;
        while (bandera) {
            try {
                DNI= inputs.nextInt();
                bandera= false;
            } catch (InputMismatchException e) {
                System.out.println("ERROR, esta ingresando caracteres invalidos:\n"+
                e+"\nPor favor ingrese un DNI:");
                inputs.nextLine();
            }
        }
        System.out.println("Ingrese edad:");
        int edad=0;
        bandera= true;
        while (bandera) {
            try {
                edad= inputs.nextInt();
                bandera= false;
            } catch (InputMismatchException e) {
                System.out.println("ERROR, esta ingresando caracteres invalidos:\n"+
                e+"\nPor favor ingrese una edad:");
                inputs.nextLine();
            }
        }
        inputs.nextLine();

        Persona persona= new Persona(nombre, apellido, genero, DNI, edad);
        return persona;
    }

    public static void main(String[] args) {
        
        Persona conductor_1= cargarPersona();
        //conductor1.verDatos();
        Persona pasajero_1= cargarPersona();
        //cargar en moto

        Persona conductor_2= cargarPersona();
        Persona pasajero1_2= cargarPersona();
        Persona pasajero2_2= cargarPersona();
        Persona pasajero3_2= cargarPersona();
        //cargar en auto

        Persona conductor_3= cargarPersona();
        Persona pasajero1_3= cargarPersona();
        Persona pasajero2_3= cargarPersona();
        Persona pasajero3_3= cargarPersona();
        Persona pasajero4_3= cargarPersona();
        //cargar en camioneta
    }
}