public interface IDescontable {
    
    public void aplicarDescuento(int edad);
}
