package ParcialZork;

import java.util.Map;
import java.util.List;

public class AppZork {
    public static void main(String[] args) {
        //No me acuerdo como es el ejemplo de Zork y no se como funciona el juego. Arme las clases y todo pero no se como funciona.
    }
}

class Juego{
    Jugador jugador;
    Map<String,Escena> escenas = new Map<>();

    void iniciar(){
        jugador = new Jugador();
    }

    void cambiarEscena(String nombreEscena){
        
    }
}

class Escena {
    String descripcion;
    List<Objeto> objetos = new List<>();
    Map<String, Escena> siguientes = new Map<>();

    public Escena(String descripcion) {
        this.descripcion = descripcion;
    }

    void agregarObjeto(Objeto objeto){
        objetos.add(objeto);
    }

    void agregarSalida(String direccion, Escena escena){

    }
}

class Jugador {
    String nombre;
    List<Objeto> inventario = new List<>();

    public Jugador(String nombre) {
        this.nombre = nombre;
        inventario.add(objeto);
    }

    void tomarObjeto(Objeto objeto){

    }

    void usarObjeto(Objeto objeto){

    }
}

class Objeto {
    String nombre;
    String descripcion;

    Objeto(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }
}
