public class Auto extends Vehiculo {
    
    public Auto(){}
    public Auto(String codigo, double costoAlquiler){
        super(codigo, costoAlquiler, 4);
    }
}
